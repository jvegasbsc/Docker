Core Developers         {#devs}
===============

Tempo2 development team
=======================
Tempo2 was origianaly written by George Hobbs and Rusell Edwards.


Core package maintainers
------------------------
+ George Hobbs [GH] \anchor GH  george.hobbs@csiro.au
 - Core tempo2 development.
 - Gravitational wave codes.
 - Binary models.
+ Michael Keith [MJK] \anchor MJK  mkeith@pulsarastronomy.net
 - C++ code maintainence.
 - Linear algebra and least-squares algorithms.
 - Build system maintainence.
 - Unit testing.


Active contributors
-------------------
+ Joris Verbiest
+ Lindley Lentati
+ Ryan Shannon
+ Paul Demorest
+ Lucas Guillemot
+ Stefan Oslowski
+ Willem van Straten
+ Rutger van Haasteren
+ Anne Archibald


Past Contributors
---------------
+ Russell Edwards
+ Aiden Hotan
+ Ankur Chaudhary
+ Ingrid Stairs

