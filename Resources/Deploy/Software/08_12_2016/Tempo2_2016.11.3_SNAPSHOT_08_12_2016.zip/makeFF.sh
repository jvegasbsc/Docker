#!/bin/bash



echo "double t2FitFunc$1(pulsar *psr, int ipsr ,double x ,int ipos ,param_label label,int k);"
echo "void t2UpdateFunc$1(pulsar *psr, int ipsr ,param_label label,int k, double val, double err);"
