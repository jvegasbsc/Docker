#include <tempo2.h>
double t2FitFunc_stdPosition(pulsar *psr, int ipsr ,double x ,int ipos ,param_label label,int k);
void t2UpdateFunc_stdPosition(pulsar *psr, int ipsr ,param_label label,int k, double val, double err);
