c      $Id$
	common/bcom/ p0firs,sigma1,asig,ct1,ctmax
