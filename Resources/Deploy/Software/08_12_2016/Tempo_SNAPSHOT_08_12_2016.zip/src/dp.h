c      $Id$
        common/dp/ pepoch,ct,f0,f1,p0,p1,p2,f2,f3,f4(NFMAX-3),
     +    dmcof(NDMCOFMAX),dmvar1,dmvar2

