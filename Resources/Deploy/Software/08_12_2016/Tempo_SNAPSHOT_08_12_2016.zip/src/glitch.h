c      $Id$
	real*8 glph(NGLT), glf0(NGLT), glf1(NGLT),
     :      glf0d(NGLT),gltd(NGLT),glepoch(NGLT)
	common/glitch/glph,glf0,glf1,glf0d,gltd,glepoch,ngl
