c NOTE: this code isn't presently used.
c	$Id$
	common/ut1/kind,int,units,mjd1,mjd2,nvtot,iut(NUTMAX)
