c      $Id$
	logical lresid1,ldesign,ldcov
	common/vcom/lresid1,ldesign,ldcov
